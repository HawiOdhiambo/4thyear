<!DOCTYPE html>
<html lang="en">
<head>
  <title>View schools</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
<body>

<div class="container">
  <h2>VIEW SCHOOLS</h2>
<?php
require 'includes/headers.php';
require 'db.php';

if(isset($_GET['success'])){
	?><div class="label label-success">Edited Successfully</div><?php
}else if(isset($_GET['error'])){
	?><div class="label label-error"> Error while editing </div><?php
}
if(isset($_GET['success1'])){
	?><div class="label label-success">Deleted Successfully</div><?php
}else if(isset($_GET['error'])){
	?><div class="label label-error"> Error while deleting </div><?php
}
if(isset($_GET['success2'])){
	?><div class="label label-success"> Deleted Successfully</div><?php
}else if(isset($_GET['error'])){
	?><div class="label label-error"> Error while deleting </div><?php
}

?>



<?php
$sql = "SELECT SCH_ID, Name, Curriculum FROM school_details";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
	echo"<table><tr><th>SCH_ID</th><th>School Name</th> <th> Curriculum </th></tr>";
    while($row = mysqli_fetch_assoc($result)) {
        echo "<tr><td>" .$row["SCH_ID"]. "</td><td>" .$row["Name"]. "</td><td> " .$row["Curriculum"].  "</td><td> <a href ='edit.php?edit=$row[SCH_ID]'> Edit </a> <a href ='delete.php?delete=$row[SCH_ID]'> Delete </a> <a href ='map.html'> Add location  </tr>";
    }
	echo"</table>";
} else { 
    echo "0 results";
}

mysqli_close($conn);
?>
</div>
</body>
</html>