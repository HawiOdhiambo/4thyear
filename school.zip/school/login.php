<?php
session_start();
require("db.php");
require('includes\headers1.php');
if(isset($_GET['success'])){
	echo"Successfully registered. Login below";
	}


	
$message="";
if(!empty($_POST["login"])) {
	if (isset ($_POST['email'], $_POST ['psw'] )){
				$email=mysqli_real_escape_string($conn, $_POST['email']);
				$psw=mysqli_real_escape_string($conn, $_POST['psw']);	
		$result = mysqli_query($conn,"SELECT * FROM users WHERE Email='$email' and Password = '$psw'");
		$row  = mysqli_fetch_array($result); 
		if(is_array($row)) {
		$_SESSION["User_ID"] = $row['User_ID'];
			if($row['First_Time']==0){
				header("location:school_homepage1.php?success");
			}
			else{
				header("location:school_homepage.php?success");
			}	
		
		} else {
		$message = "Invalid Username or Password!";
		}
	}
}

?>


<div class="container-fluid text-center" style="margin-top: 200px">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
<div class="jumbotron">
<?php if(empty($_SESSION["User_ID"])) { ?>
<form action="" method="post" id="frmLogin">
	<div class="error-message"><?php if(isset($message)) { echo $message; } ?></div>	
	
		<label>Email</label>
		<input name="email" type="text" class=""
		<?php if(isset($_SESSION['email'])){?> value = <?php echo $_SESSION['email']; } ?>
		>

		<label>Password</label>
		<input name="psw" type="password" class=""> 
	
		<input type="submit" name="login" value="Login" class="">	      
</form>
</div>
 </div>
</div>
</body>
<?php 
} 
?>
</body>
</html>