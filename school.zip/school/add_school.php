
<?php
session_start();
require("db.php");
	$id = $_SESSION['User_ID'];
	echo $id;
	$result = mysqli_query($conn,"SELECT * FROM users WHERE User_ID = $id ");
	$row  = mysqli_fetch_array($result);



if (isset ($POST['school_name'], $POST ['curriculum'] )){
	$school_name=$REQUEST['school_name'];
	$curriculum=$REQUEST['curriculum'];
}
 if (!empty($_POST['school_name'])){
$school_name=mysqli_real_escape_string($conn, $_POST['school_name']);
$curriculum=mysqli_real_escape_string($conn, $_POST['curriculum']);
 } else{
 $school_name= null;
 $curriculum=null;
 }
$sql = "INSERT INTO school_details (User_ID, Name, Curriculum)
VALUES ('$id', '$school_name', '$curriculum')";

if (mysqli_query($conn, $sql)) 
			header("location:http://localhost/school/school_homepage.php?success");
		else 
			header("location:view_schools.php?error");

mysqli_close($conn);
?>