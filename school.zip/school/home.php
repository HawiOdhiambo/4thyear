<?php
require('includes\headers1.php');


?>
<head>
<link rel="stylesheet" type="text/css" href="includes\index.css">
</head>


<div class="container-fluid text-center" style="margin-top:100px">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
      <h1 style="color: red; font-weight: 700; left: 30px;"> Tashu</h1>
	  <h2 style="color: #484848;">The best place to find a school. </h2>
		
		<div style="height: 200px;">
		<h3 style="position:relative; left: 30px;"> Discover the perfect school for your child </h3>
		<p style="position:relative; left: 50px; font-size: 15px; color: green;">Looking for a school, Try out our interactive search box below</p>
			<form class="form-inline" >
			
         	<div style="margin:30px;">
			
			<div  class="form-control inputABC" id="clickLoc" style="display:inline-block;">
            <input type="text"  id="place" class="inputLocation"  placeholder="Try Otiende"  />
			<i class="glyphicon glyphicon-map-marker" id="myloc"> </i>
			</div>
		
	
            <input class="form-control inputABC"  type="text" id="curriculum"  placeholder="Try 844" >
			
			<input type="button" id="submit" class= "btn btn-default inputABC" value="Search"/>  
			</div>
			
			</form>
		</div>
		
	
			
			
			</div>
			 
		<div class="col-sm-2 sidenav">
			<!--<div class="well">
			<p>ADS</p>
			</div>
		<div class="well">-->        
			</div>
	
			</div>
			</div>
		<div class="row content" style="height:100px;" >
			  
		</div>
<script>
 document.getElementById('submit').addEventListener('click', function () {

		var address = document.getElementById('place').value;
		var curriculum = document.getElementById('curriculum').value;

		console.log(address);
		console.log(curriculum);
		//alert(address);
		var geocoder = new google.maps.Geocoder();
         geocoder.geocode({'address': address}, function(results, status) {
           if (status == google.maps.GeocoderStatus.OK) {
            alert(results[0].geometry.location);
			var loc=results[0].geometry.location;
			console.log(loc.lat());
			console.log(loc.lng());
			console.log(curriculum);
			window.location.href ='get_school.php?curriculum=' + curriculum + '&lat=' + loc.lat() + '&lng=' + loc.lng();
           } else {
             alert(address + ' not found');
           }
         });
		//console.log(address);
	       });
		   
 document.getElementById('myloc').addEventListener('click', function () {
    if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(success);
	
		
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
});  

function success(pos) {
  var crd = pos.coords;

  console.log('Your current position is:');
  console.log(`Latitude : ${crd.latitude}`);
  console.log(`Longitude: ${crd.longitude}`);
  console.log(`More or less ${crd.accuracy} meters.`);
  // document.getElementById('').value;
};


document.getElementById('clickLoc').addEventListener('click', function () {
	window.location="get_school_home.php?location";

});

 
 
 
 
 
 
 
 
 
 
 
 var x = document.getElementById("demo");

function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}  



function showPosition(position) {
    x.innerHTML = "Latitude: " + position.coords.latitude + 
    "<br>Longitude: " + position.coords.longitude;
	initMap(position.coords.latitude, position.coords.longitude);
	console.log('Hi');
}

  var map;
      function initMap(lat, lng) {
	  var lat=parseFloat(lat);
	  var lng=parseFloat(lng);
	  
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: lat, lng: lng},
          zoom: 13
        });
      }





</script>



		
   
  



</body>
</html>
