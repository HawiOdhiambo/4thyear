<?php
	include_once("db.php");
	
	//echo $music;


	if (isset($_GET['submit']))
	{
		$new_school_name=$_GET['new_school_name'];
		$User_ID=$_GET['User_ID'];
		$curriculum=$_GET['curriculum'];
		$type=$_GET['type'];
		$bgm=$_GET['bgm'];
		$religion=$_GET['religion'];
		$specialType=$_GET['specialOptsA'];
		$specClass=$_GET['specClass'];
		$specialOptsB=$_GET['specialOptsB'];
		$day_board=$_GET['day_board'];
		$message=$_GET['message'];
		$FeeRange=$_GET['FeeRange'];
		$dayFee=$_GET['dayFee'];
	
		//$checkbox[5]= $_GET['extra_curr'];
	//var_dump($_GET);
		if(!isset($_GET['extra_curr0'])){
			$music = 'N';
		}else{
			$music=$_GET['extra_curr0'];
		}
		
		if(!isset($_GET['extra_curr1'])){
			$french = 'N';
		}else{
			$french=$_GET['extra_curr1'];
		}
		
		if(!isset($_GET['extra_curr2'])){
			$german = 'N';
		}else{
			$german=$_GET['extra_curr2'];
		}
		
		if(!isset($_GET['extra_curr3'])){
			$chinese = 'N';
		}else{
			$chinese=$_GET['extra_curr3'];
		}
		
		if(!isset($_GET['extra_curr4'])){
			$m_art = 'N';
		}else{
			$m_art=$_GET['extra_curr4'];
		}		
		
		
		/*$french=$_GET['extra_curr1'];
		
		$german=$_GET['extra_curr2'];
		
		$chinese=$_GET['extra_curr3'];
		
		$m_art=$_GET['extra_curr4'];
		
		if(!$music){
			$music='N';
		}
		if(!$french){
			$french='N';
		}
		if(!$german){
			$german='N';
		}
		if(!$chinese){
			$chinese='N';
		}
		
		if(!$m_art){
			$m_art='N';
		}*/
		echo  $User_ID;
		echo $french;
		echo $german;
		echo $chinese;
		echo $bgm;
		
		$sql= "UPDATE users
		INNER JOIN school_details ON (users.User_ID=school_details.User_ID)
		INNER JOIN location ON (school_details.User_ID=location.User_ID)
		INNER JOIN extra_curriculum ON (location.User_ID=extra_curriculum.User_ID)
		SET users.School_name='$new_school_name', school_details.Curriculum='$curriculum', location.type='$type',
			school_details.BGM='$bgm', school_details.Religion='$religion',
			 extra_curriculum.music='$music',  extra_curriculum.french='$french',  extra_curriculum.german='$german',
			  extra_curriculum.chinese='$chinese',  extra_curriculum.M_arts='$m_art',
			  school_details.SpecialType='$specialType', school_details.SpecialRadio='$specClass',
			  school_details.SpecialClass='$specialOptsB',school_details.day_board='$day_board', school_details.motto='$message',
			  school_details.dayFee='$dayFee', school_details.FeeRange='$FeeRange'
		WHERE users.User_ID='$User_ID' AND school_details.User_ID='$User_ID' AND extra_curriculum.User_ID= '$User_ID' ";	
		if (mysqli_query($conn, $sql)) {
			echo"success";
			header("location:school_homepage.php?success");
		}
		else {
			echo "Error:  ",mysqli_error($conn);
			header("location:school_homepage.php?error");
		}
			
		
		
		

	 } 	

?>
