<?php

require("db.php");
session_start();
$id =  $_GET['id'];



// Start XML file, create parent node

$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);

// Select all the rows in the markers table

$query = "SELECT * FROM location WHERE User_ID = $id";
$result = mysqli_query($conn, $query);
if (!$result) {
  die('Invalid query: ' . mysqli_error($conn));
}

$q = "SELECT * FROM users WHERE User_ID=$id";
$r= mysqli_query($conn, $q);
if (!$r) {
  die('Invalid query: ' .  mysqli_error($conn));
}

header("Content-type: text/xml");

// Iterate through the rows, adding XML nodes for each

while ($row = @mysqli_fetch_assoc($result)){
  // Add to XML document node
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("id",$row['id']);
  
  $newnode->setAttribute("address", $row['address']);
  $newnode->setAttribute("lat", $row['lat']);
  $newnode->setAttribute("lng", $row['lng']);
  $newnode->setAttribute("type", $row['type']);
  while ($ro = @mysqli_fetch_assoc($r)){

  $newnode->setAttribute("name",$ro['School_name']);

}
}



echo $dom->saveXML();

?>