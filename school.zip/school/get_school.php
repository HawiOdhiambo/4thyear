<?php
require("db.php");



if(isset($_GET['SchName'])){
	$SchName=$_GET['SchName'];
}
if(empty($_GET['SchName']) ){
	$SchName="";
}


if(isset($_GET['curriculum'])){
$curriculum = $_GET['curriculum'];
}
if(empty($_GET['curriculum'])){
$curriculum = "";
}



if(isset( $_GET['lat'])){
$lat = $_GET['lat'];
}
if(empty( $_GET['lat'])){
$lat = "";
}


if(isset($_GET['lng'])){
$lng = $_GET['lng'];
}

if(empty($_GET['lng'])){
$lng = "";
}

if(isset($_GET['type'])){
	$type = $_GET['type'];
}
if(empty($_GET['type'])){
	$type = "";
}
	
	
if(isset( $_GET['rel'])){
	$str= $_GET['rel'];
	$rel=preg_replace('/\s+/', '', $str);
	//echo $rel;
}
if(empty( $_GET['rel'])){
	$rel= "";
}


if(isset( $_GET['db'])){
	$db= $_GET['db'];
}
if(empty( $_GET['db'])){
	$db= "";
}

if(isset($_GET['feeR'])){
	$feeR= $_GET['feeR'];
}
if(empty($_GET['feeR'])){
	$feeR= "";
}

if(isset($_GET['DFeeID'])){
	
	$DFeeID= $_GET['DFeeID'];
}
if(empty($_GET['DFeeID'])){
	
	$DFeeID= "";
}


if(isset( $_GET['SOptsA'])){
	
	$SOptsA=  $_GET['SOptsA'];
}

if(empty( $_GET['SOptsA'])){
	
	$SOptsA=  "";
}


if (isset($_GET['SOptB'])){
	$SOptB= $_GET['SOptB'];
}

if (empty($_GET['SOptB'])){
	$SOptB="";
}

if (isset($_GET['bgm'])){
	$bgm= $_GET['bgm'];
	
}

if (empty($_GET['bgm'])){
	$bgm= "";
	
}

if(isset( $_GET['french'])){
	$french= $_GET['french'];
}

if(empty( $_GET['french'])){
	$french= "";
}

if(isset($_GET['german'])){
	$german= $_GET['german'];
}
if(empty($_GET['german'])){
	$german="";
}

if(isset($_GET['chinese'])){
	$chinese= $_GET['chinese'];
}
if(empty($_GET['chinese'])){
	$chinese= "";
}


if(isset( $_GET['music'])){
	$music= $_GET['music'];
}
if(empty( $_GET['music'])){
	$music="";
}


if (isset( $_GET['mArts'])){
	$mArts= $_GET['mArts'];
}
if (empty( $_GET['mArts'])){
	$mArts= "";
}



if(isset( $_GET['radio'])){
$radio= $_GET['radio'];	
}

if(empty( $_GET['radio'])){
$radio= "";	
}


if(empty( $_GET['search'])){
	
if (isset( $_GET['radius'])){
	$radius = $_GET['radius'];
	//echo $radius;
}
 if (empty( $_GET['radius'])) {
$radius = 4;	
//echo $radius;
}
	
}

if(isset($_GET['search'])){
$radius = "";		
	
}

//echo $radius;
if (isset( $_GET['button'])){
	$button = $_GET['button'];
	//echo $button;
}

//echo $curriculum, "<br />" ,$lat, "<br />", $lng;
$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);

//printf(" curriculum %s", mysqli_real_escape_string($conn, $curriculum));
//% AND school_details.day_board LIKE'% AND school_details.dayFee LIKE'% AND sc

$query = sprintf("SELECT users.School_name, users.Email, users.Tel_no, school_details.User_ID, school_details.curriculum,
					location.id, location.address, location.type, location.lat, location.lng, school_details.motto,school_details.User_ID,
			(6371 * acos( cos( radians('%s') ) * cos( radians( lat ) ) * cos( radians( lng ) - radians('%s') ) + sin( radians('%s') ) * sin( radians( lat ) ) ) )
AS distance
			  FROM location INNER JOIN  school_details ON location.User_ID=school_details.User_ID 
			  INNER JOIN users ON school_details.User_ID=users.User_ID
			  INNER JOIN extra_curriculum ON users.User_ID=extra_curriculum.User_ID
 WHERE  
		school_details.Religion LIKE '%s%%' 
		
	AND school_details.Curriculum LIKE'%s%%' AND location.type LIKE'%s%%' 
		AND school_details.BGM LIKE'%s%%'
		AND school_details.SpecialType LIKE'%s%%' AND  school_details.SpecialRadio LIKE'%s%%'
		AND school_details.SpecialClass LIKE'%s%%' AND school_details.day_board LIKE '%s%%'
		AND school_details.dayFee LIKE'%s%%' AND school_details.FeeRange LIKE'%s%%'
		AND  extra_curriculum.Music LIKE'%s%%' AND  extra_curriculum.French LIKE'%s%%'
		AND  extra_curriculum.German LIKE'%s%%' AND  extra_curriculum.Chinese LIKE'%s%%'
		AND  extra_curriculum.M_arts LIKE'%s%%' 
		
 HAVING distance < '%s' ORDER BY distance LIMIT 0 , 20",

  mysqli_real_escape_string($conn, $lat),
  mysqli_real_escape_string($conn, $lng),
  mysqli_real_escape_string($conn, $lat),
  mysqli_real_escape_string($conn, $rel),
  	mysqli_real_escape_string($conn, $curriculum),
    mysqli_real_escape_string($conn, $type),
	mysqli_real_escape_string($conn, $bgm),
	 mysqli_real_escape_string($conn,  $SOptsA),
	 mysqli_real_escape_string($conn,  $radio),
	 mysqli_real_escape_string($conn, $SOptB),
	 mysqli_real_escape_string($conn,  $db),
	 mysqli_real_escape_string($conn,  $DFeeID),
	mysqli_real_escape_string($conn,  $feeR),
	mysqli_real_escape_string($conn,$music),
	mysqli_real_escape_string($conn, $french),
	mysqli_real_escape_string($conn, $german),
	mysqli_real_escape_string($conn,$chinese),
	mysqli_real_escape_string($conn,$mArts),
	mysqli_real_escape_string($conn, $radius));
  
  //echo $rel;
  //print_r($rel);
 //echo $query;

  if ($result=mysqli_query($conn, $query))
  {
	 // echo"Query is alright";
	  
	  if(isset ($button)){
		  
			
		 // echo"button entered";
			header("Content-type: text/xml charset=utf-8");
			// Iterate through the rows, adding XML nodes for each
			while ($row = @mysqli_fetch_assoc($result)){
			  $node = $dom->createElement("marker");
			  $newnode = $parnode->appendChild($node);
			   $newnode->setAttribute("name", $row['School_name']);
			  $newnode->setAttribute("id", $row['User_ID']);
			  $newnode->setAttribute("type", $row['type']);
			  $newnode->setAttribute("address", $row['address']);
			  $newnode->setAttribute("lat", $row['lat']);
			  $newnode->setAttribute("lng", $row['lng']);
			  $newnode->setAttribute("distance", $row['distance']);
			}
			echo $dom->saveXML();
		  
	  }
	  else{
		$rowcount=mysqli_num_rows($result);
		echo "<table class= 'table table-hover'>";
		session_start();
	
		printf("Results %d rows", $rowcount);
		while($row = mysqli_fetch_assoc($result)){
	echo "<tr class='success row' onclick='myTracker(" .$row['User_ID']. ")'  ><td style='font-weight: 700;  padding: 30px;'> School Name:</td><td  style='padding: 30px;'>".$row['School_name']."</td>
														<td style='font-weight: 700; padding: 30px;'> School Motto:<td style='padding: 30px;'>".$row['motto']. "</td>
														<td  style=' font-weight: 700; padding: 30px;'> Address: <td  style='padding: 30px;'>".$row['address']. "</td></tr>"
									
														;
														
		}
		echo "</table>";
		echo $rel;
	 }
  } 
  else{
	  echo ("Invalid query: " . mysqli_error($conn));
  }
  

?>