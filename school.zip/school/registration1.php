
<?php
session_start();

require('includes\headers1.php');
if(!empty($_POST["register_user"])) {
	/* Form Required Field Validation */
	foreach($_POST as $key=>$value) {
		if(empty($_POST[$key])) {
		$error_message = "All Fields are required";
		break;
		}
	}
	/* Password Matching Validation */
	if($_POST['psw'] != $_POST['psw_repeat']){ 
	$error_message = 'Passwords should be same<br>'; 
	}

	/* Email Validation */
	if(!isset($error_message)) {
		if (!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)) {
		$error_message = "Invalid Email Address";
		}
			$email=mysqli_real_escape_string($conn, $_POST['email']);
			$checkEmail=mysqli_query($conn, "SELECT * from users WHERE Email='$email'");
				$checkE=mysqli_fetch_array($checkEmail);
				 if(!empty ($checkE)){
					 $error_message="Email already exists";
				 }
				
	}


	}

	if(!isset($error_message)) {
		
			
		if (isset ($_POST['school_name'], $_POST ['email'], $_POST['tel_no'], $_POST ['psw'], $_POST ['psw_repeat'] )){
			$school_name=mysqli_real_escape_string($conn, $_POST['school_name']);
			$email=mysqli_real_escape_string($conn, $_POST['email']);
			$tel_no=mysqli_real_escape_string($conn, $_POST['tel_no']);
			$psw=mysqli_real_escape_string($conn, $_POST['psw']);
			$psw_repeat=mysqli_real_escape_string($conn, $_POST['psw_repeat']);
			echo"Hello you!!";
			$query = "INSERT INTO users (School_name, Email, Tel_no, Password, Rpt_password) VALUES
			('$school_name', '$email', '$tel_no', '$psw', '$psw_repeat')";
			$result= mysqli_query($conn, $query);
			
					$r = mysqli_query($conn,"SELECT * FROM users WHERE Email= '$email' ");
					$row  = mysqli_fetch_array($r);
					$id=$row['User_ID'];
					$res=mysqli_query($conn,"INSERT INTO school_details(User_ID) VALUES('$id')");
					if(!empty($res)) {
						echo"successfully entered User ID to School details table";
					} else {
						$error_message = "Problem in adding User ID to School details table!";	
					}
					
					$value=mysqli_query($conn, "INSERT INTO location(User_ID) VALUES('$id')");
					if(!empty($value)) {
						echo"successfully entered User ID to Location table";
					} else {
						$error_message = "Problem in adding User ID to Location table!";	
					}
					
					$val=mysqli_query($conn, "INSERT INTO extra_curriculum(User_ID) VALUES('$id')");
					if(!empty($val)) {
						echo"successfully entered User ID to Location table";
					} else {
						$error_message = "Problem in adding User ID to Location table!";	
					}
					
					if(!empty($result)) {
				$_SESSION['email']=$email;
						echo $_SESSION['email'];
						
						echo "successful";
						// echo'<META HTTP-EQUIV="Refresh"  URL=http://localhost/school/login.php?success">';
						  $success_message="Successfully Registered";
						  
						  header("Refresh:0; url=login.php?success");
						  
						  // echo'<META HTTP-EQUIV="Refresh"  URL=http://localhost/school/login.php?success">';
						//header("refresh; location:login.php?success&email=$email");
						
					} else {
						$error_message = "Problem in registration. Try Again!";	
					}
		}
					
					
			
	}

?>



<div class="container-fluid text-center" style="margin-top:50px">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left">
<?php


?>	
<div class="jumbotron">



  <h2>REGISTRATION FORM</h2>
  <form name="registration_form" id="registration_form"  method="post" action= "">
  <div class="form-group">
		<?php if(!empty($success_message)) { ?>	
	<div class="success-message"><?php if(isset($success_message)) echo $success_message; ?></div>
	<?php } ?>
	<?php if(!empty($error_message)) { ?>	
	<div class="error-message"><?php if(isset($error_message)) echo $error_message; ?></div>
	<?php } ?>	
	
		School name:<br>
		<input id="school_name" class="form-control"type="text" name="school_name" placeholder="Enter School name"<?php if(isset($_POST['school_name'])){?> value = <?php echo $_POST['school_name']; ?>
		<?php } ?>
		autocomplete="off"
		>
		<br>
		Email:<br>
		<input type="text" class="form-control" placeholder="Enter Email" name="email" <?php if(isset($_POST['email'])){?> value = <?php echo $_POST['email']; ?>
		<?php } ?>
		
		><br>
		
		
		Telehone no:<br>
		<input type="text" class="form-control" placeholder="Enter Phone number" name="tel_no" <?php if(isset($_POST['tel_no'])){?> value = <?php echo $_POST['tel_no']; ?>
		<?php } ?> 
		
		><br>

		Password:<br>
		<input type="password" class="form-control" placeholder="Enter Password" name="psw" ><br>

		Repeat Password:<br>
		<input type="password" class="form-control" placeholder="Repeat Password" name="psw_repeat" " ><br>
		
		<input type="submit" name="register_user" value="Register">
		<input type="button" onclick="resetform()" id="register_user" value="Reset Form" ">
		<script>

		function resetform(){
			document.getElementById("registration_form").reset();
		}
  
		</script>  
  
     	
  </form>

  
</div>
</div
</div>
 </div>
</div>


</body>
</html>