
<?PHP
require("db.php");
$rel="Christian";
 $query = sprintf("SELECT  school_details.Curriculum FROM school_details
 WHERE  school_details.Religion LIKE '%s%%'", 
 mysqli_real_escape_string($conn, $rel));
 
 print_r($query);
  
$result=mysqli_query($conn, $query);
while ($row  = mysqli_fetch_array($result)){
	
 echo $row['Curriculum'];
}

 
		
?>