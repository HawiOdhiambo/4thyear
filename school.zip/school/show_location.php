<?php
require("includes\headerNavigationBar.php");

//echo $_SESSION['User_ID'];
?>
<!DOCTYPE html >
  <head>
	
  
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
	
    <title>Show Location</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
		  
		   position: relative;
		   overflow: hidden;
		   height: 50%;
		   border-style: solid;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
	  p{
		position: relative;
		left: 50px;
	  }
	  .center{
		  
		  width: 80%;
		  margin: auto;
	  }
	  a:hover {
		  text-decoration:underline;
	  }
    </style>
  </head>

  <body>
		
		<div class="center" style="margin-top: 100px;">
		<h1> My location </h1>
		<p class="text-primary center"><a href ="http://localhost/school/school_homepage.php">Home</a> <span class="glyphicon glyphicon-chevron-right"></span> <a href ="">Current location </a></p>
	
		<a  class="btn btn-success" href="http://localhost/school/add_location.php" style="position: relative; left: 830px;"> <span class="glyphicon glyphicon-pencil"></span>  Edit location </a>  
		</div>
		</br>
		<div id="map" class="center"> </div>
		 <p class="center" style="color:red;">Click on the marker to view your location details </p> 
	
	    <script>
		
	function Edit_location()
	{
		document.getElementById("map").innerHTML=Date()		
	}
		
      var customLabel = {
        kindergaten: {
          label: 'K'
        },
        primary: {
          label: 'P'
        },
		special:{
			label: 'S'
		},
		daycare:{
			label: 'D'
		}
      };

        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(-1.2920, 36.8219),
          zoom: 13
		  
        });
        var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file
          downloadUrl('http://localhost/school/show_location1.php', function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
			 //var bounds = new google.maps.LatLngBounds();
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var name = markerElem.getAttribute('name');
              var address = markerElem.getAttribute('address');
              var type = markerElem.getAttribute('type');
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = name
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));
			
				map.setCenter(point);
			
			
              var text = document.createElement('text');
              text.textContent = address
              infowincontent.appendChild(text);
              var icon = customLabel[type] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label
              });
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDj8AVejS_y_93KkYOc0Tsq86SRNk5l7lM&callback=initMap">
    </script>

  </body>
</html>