<?php
require("db.php");
session_start();

	$id = $_SESSION['User_ID'];
	$result = mysqli_query($conn,"SELECT * FROM users WHERE User_ID = $id ");
	$row  = mysqli_fetch_array($result);
// Gets data from URL parameters.
$name = $_GET['name'];
$address = $_GET['address'];
$lat = $_GET['lat'];
$lng = $_GET['lng'];
$type = $_GET['type'];

//UPDATE users SET School_name='$new_school_name' WHERE User_ID='$User_ID';
//sprintf("UPDATE location SET address = %s,  lat = %s, lng = %s type=%s WHERE User_ID='$id'"
// Inserts new row with place data.
$query =sprintf("UPDATE location SET address = '%s',  lat = '%s', lng = '%s', type='%s' WHERE User_ID='$id'",
        
         mysqli_real_escape_string($conn, $address),
         mysqli_real_escape_string($conn, $lat),
         mysqli_real_escape_string($conn,$lng),
         mysqli_real_escape_string($conn, $type));

$result = mysqli_query($conn, $query);

if ($result){
	
		 echo"Successfully pined your location";
}else {
	
	echo "error";
}

mysqli_close($conn);

?>