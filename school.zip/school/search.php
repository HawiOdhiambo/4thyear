<?php
require("db.php");
require('includes\headers1.php');
if(isset($_GET['search'])){
$search= $_GET['search'];
} 
if(empty($_GET['search'])){
	$search='';
}

$query = sprintf("SELECT users.*, school_details.*, location.* FROM users
		INNER JOIN  school_details ON users.User_ID=school_details.User_ID 
		INNER JOIN  location ON school_details.User_ID=location.User_ID 
		WHERE School_name LIKE '%s%%'",   mysqli_real_escape_string($conn, $search));

 
 
?>

<head>
<link rel="stylesheet" type="text/css" href="includes\index.css">
</head>
<div class="container-fluid text-center" style="margin-top:100px">   
<form class="form-inline"  method="GET" >
			
         	<div style="margin:30px;">
			
			<div  class="form-control inputABC" id="clickLoc" style="display:inline-block; width: 600px;">
            <input type="text"name="search" class="inputLocation"  style="    width: 389px;" placeholder="Search for a school"  />
			
			</div>
		
			<input type="submit" id="submit" class= "btn btn-success inputABC" style="width: 126px;"value="Search"/>  
			</div>
			
			</form>
<div id="responsecontainer" class="jumbotron" style="display:block; margin:auto; width:60%;">
				
<?php

	
echo "<table class= 'table table-hover'>";
if ($result=mysqli_query($conn, $query)){
	 
	 while($row = mysqli_fetch_assoc($result)){
	echo "
		<tr class='success row' onclick='myTracker(" .$row['User_ID']. ")'  ><td style='font-weight: 700;  padding: 30px;'> School Name:</td><td  style='padding: 30px;'>".$row['School_name']."</td>
														<td style='font-weight: 700; padding: 30px;'> School Motto:<td style='padding: 30px;'>".$row['motto']. "</td>
														<td  style=' font-weight: 700; padding: 30px;'> Address: <td  style='padding: 30px;'>".$row['address']. "</td></tr>"
									
														;
														
		}
		echo "</table>";
	
	 }
		else{
			echo "Quey error";
				echo "Error:  ",mysqli_error($conn);
		}
?>		

</div>	

<script>
function myTracker(id){
console.log(id);
//'add_location1.php?name=' + name + '&address=' + address +
window.location.href='tracking.php?id=' + id;

}
</script>