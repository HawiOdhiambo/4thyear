<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add school form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script>
function validateForm() {
    var schoolname = document.getElementById("school_name").value
console.log(x);
        alert("Name must be filled out");
       
}
</script>  
</head>
<?php
session_start();
require("db.php");
	$id = $_SESSION['User_ID'];
	echo $id;
	$result = mysqli_query($conn,"SELECT * FROM users WHERE User_ID = $id ");
	$row  = mysqli_fetch_array($result);
?>

<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="http://localhost/school/school_homepage.php">Home</a></li>
      
      </ul>
	  
      <ul class="nav navbar-nav navbar-right">
		<li class="navbar-text">Welcome <?php echo ucwords($row['School_name']); ?>!</li>
        <li><form action="" method="post" id="frmLogout"> <input type="submit" name="logout" value="Logout" class="btn btn-danger">	</form></li>
      </ul>
    </div>
  </div>
</nav>
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
	<div class="jumbotron">
  <h2>ADD NEW SCHOOL</h2>
  <form name="School_form" action="add_school.php" onsubmit="validateForm()" method="POST"  >
		
		 
		Curriculum:<br>
		<select class="form-control" name="curriculum">
			<option value="">  </option>
			<option value="IGCSE"> IGCSE </option>
			<option value="844"> 844 </option>
			<option value="IGCSE_and_844"> IGCSE and 844 </option>
		</select>
			<br><br>
 
		<input type="submit" value="Add school">
		<input type ="reset" value="Reset form">
		
  </form>
</div>
  </div>
</div>
</body>

</html>