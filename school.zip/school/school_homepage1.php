<?php
session_start();
if(isset($_GET['success'])){
	
	}

	require("db.php");
	$id = $_SESSION['User_ID'];
	$result = mysqli_query($conn,"SELECT * FROM users WHERE User_ID = $id ");
	$row  = mysqli_fetch_array($result);
	$sql= mysqli_query($conn, "UPDATE users SET First_Time='1' WHERE User_ID=$id");
	if($sql){
		echo"successfully changed";
	}
	else{
		echo"error in changing";
	}
	
	if(!empty($_POST["logout"])) {
	$_SESSION["User_ID"] = "";
	session_destroy();
	header("location:login.php");
	}
	
	?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>Soma School Homepage</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
      
      </ul>
	  
      <ul class="nav navbar-nav navbar-right">
		<li class="navbar-text">Welcome <?php echo ucwords($row['School_name']); ?>!</li>
        <li><form action="" method="post" id="frmLogout"> <input type="submit" name="logout" value="Logout" class="btn btn-danger">	</form></li>
      </ul>
    </div>
  </div>
</nav>


	
	<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-2 sidenav">
     
    </div>
    <div class="col-sm-8 text-left"> 
		<?php if(isset($_GET['success'])){
	?><div class="label label-success">Edited Successfully</div><?php
	}else if(isset($_GET['error'])){
	?><div class="label label-error"> Error while editing </div><?php
	}?>
      <h1 style="color: red;">Patashu</h1>
	  <h2>Home to all schools </h2>
		
		<div class="jumbotron">
		<h3> Welcome <span style="display:inline;  font-weight: bold; color: #00cc00;"><?php echo ucwords($row['School_name']); ?></span>, You have successfully logged in
	 </h3>
		<nav class="navbar navbar-default" style="width:100%;">
			<ul class="nav navbar-nav">
			<li style="border-bottom-style:solid;"><a href="http://localhost/school/edit.php" >Add Your School details</a></li>
			<li style="border-left-style:solid; border-bottom-style:solid;"><a href="http://localhost/school/add_location.php">Add and Pin your location</a> </li>
			
			</ul>
		
			</nav>
		
	
		</div>
	</div>
	</div>
	</div>
</body>