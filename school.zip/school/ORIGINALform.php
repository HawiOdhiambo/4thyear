

<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse" style="position: fixed; top: 0px; width: 100%; z-index:100;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="http://localhost/school/home.html">Home</a></li>
      
      </ul>
	  
      <ul class="nav navbar-nav navbar-right">
		
      </ul>
    </div>
  </div>
</nav>	
	<!DOCTYPE html>
	
<html lang="en">
<head>
  <title>Tashu Form Validator</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" type="text/css" href="includes\map.css">
   <link rel="stylesheet" type="text/css" href="includes\index.css">
   <script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
	<style>
	#myloc:hover {
    cursor: pointer;
	color:red;
}
#myloc:active{
	background-color:yellow;
}
#myloc:focus{
	color:green;
}

#advFormOpts,#AdvOpt:hover {
    cursor: pointer;
	color:red;
}
.row{
height:90px
}

	</style>
</head>


<body>		<div class="container"  style="margin-top:60px;">
			<h3 style="text-align:left;" id="h1Welcome" > WELCOME TO OUR INTERACTIVE SCHOOL FINDER </h1>
			<form class="form-inline" >
			
         	<div style="margin:30px;">
			
			<div  class="form-control inputABC" style="display:inline-block; " id="locationBox">
			
            <input type="text"  id="place" class="inputLocation" style="margin:0px; width: 200px;" placeholder="Enter a location like Chiromo"  />
			<i class="glyphicon glyphicon-map-marker" id="myloc" style="display:inline;" title="click to search using current location"> </i>
			<i class="glyphicon glyphicon-remove" id="remove_buttn" style="display:none;"onclick="removeinputBox()"> </i>
			<i class="glyphicon glyphicon-remove" id="return_buttn" style="display:none;"onclick="returninputBox()"> </i>
			<i class="glyphicon glyphicon-remove" id="restore_buttn" style="display:none;"onclick="restoreInputs()"> </i>
			<a  style="display:block; font-size:smaller; " id="AdvOpt"data-toggle="collapse" data-target="#radius">Advanced Options</a>
			<i class="glyphicon glyphicon-chevron-down" id="" data-toggle="collapse" data-target="#radius"style="left: 50%; top: -15px; font-size: smaller;"> </i>
			<select id="radius" class= "panel-collapse collapse">
			<option disabled selected value > --Select a radius--- </option>
			<option value="5"> Default </option>
			<option value="5"> 5 KM </option>
			<option value="7"> 7 KM</option>
			<option value="10" >10 KM</option>
			</select>
			</div>
		
			<div id="844_TYPE" style="display:none;">
           
			<!----onchange="special(this);"-->
			<select id="selectSpecial" name="type" class="form-control inputABC" onchange="special(this);"  >
			<option disabled selected value > Select Daycare/Kindergaten/Primary School/Special Needs School </option>
			<option value="" >None </option>
			<option value="daycare" > DayCare</option>
			<option value="kindergaten"> Kindergaten </option>
			<option value="primary" > Primary School </option>
			<option value="special"> Special Needs School </option>
			</select>
			<br><br>
		
			 <select id="curriculum" name="curriculum" class="form-control inputABC" style="position: relative; TOP: -67px; left: 750px;" >
			<option disabled selected value > --Select a curriculum--- </option>
			<option value="" >None </option>
			<option value="IGCSE"> IGCSE </option>
			<option value="844"> 844 </option>
			<option value="IGCSE_and_844"> IGCSE and 844 </option>
		</select>
			 
			 
			<a id="advFormOpts" data-toggle="collapse" data-target="#formADV" title="Click to view advanced form options"style="color:red;"> Advanced form options </a>
			</div>
			<script src="includes\get_school_input.js"></script>
		<!--- Beginning of form toggled-->	
		<div id="formADV" class="panel-collapse collapse" >
	 <div class="formgroup">
	 <label> Religious Values </label>
	 		 
		<select name="religion" 
				class="form-control"
				id="religionID"
				>
		<option disabled selected value >
		--Select an option--- 
		</option>
		<option value="" > None </option><option value="Buddhist ">Buddhist</option><option value="catholic ">catholic</option><option value="muslim ">muslim</option></select>	 
		<br>		
	 </br>


		<label> Day/Boarding? :<br> </label>
		<select id="dayBoardID" name="day_board" class="form-control" >
			<option disabled selected value > --Select an option--- </option>
			<option value="" >None </option>
			<option value="day"> Day</option>
			<option value="boarding"> Boarding </option>	
		</select>
		<br><br>
			
		
		<div id="feeDiv" style="display:none;">
		<label> Fee Range: </label>
		<select id="feeRangeID" name="FeeRange" class="form-control" >
			<option disabled selected value > --Select a fee range below--- </option>
			<option value="" >None </option>
			<option value="free">  free </option>
			<option value="less10"> less KSH 10,000 </option>
			<option value="10_20"> KSH 10,000 20,000</option>
			<option value="21_30" > KSH 21-30,000 </option>
			<option value="31_40" > KSH 31-40,000 </option>
			<option value="41_50" > KSH 41,000-50,000 </option>
			<option value="51_60" > KSH 51,000-60,000</option>
			<option value="61_70" > KSH 61,000-70,000 </option>
			<option value="71_80" > KSH 71,000-80,000 </option>
			<option value="81_90"> KSH 81,000-90,000 </option>
			<option value="91_100">KSH 91,000-100,000</option>
			<option value="abv100"> ABOVE 100,000 </option>
		</select>
		<br><br>
		</div>
		
		
		<div id="feeDivDayC" style="display:none;">
		<label> Day care Fee per day: </label>
			<select id="dayFeeID" name="dayFee" class="form-control" >
			<option disabled selected value > --Select a fee range below--- </option>
			<option value="" >None </option>
			<option value="less5" > less 500  per day </option>
			<option value="5_10">KSH 500- 1,000  per day </option>
			<option value="10_30" >KSH 1,000 - 2000  per day</option>
			<option value="30_50"> KSH 3,000- 5,000  per day </option>
			<option value="50_100" > KSH 5,000-10,000  per day </option>
			<option value="abv100"> ABOVE 10,000  per day</option>
			
		</select>
		
		
		<br><br>
		</div>
		<p id="errorspecialOptsA"style="display:none; color:red; font-size:14px;" ></p>
		<div id="specialA" style="display:none;">
		<label> Type of Special Needs Schools: </label>
		<select id="specialOptsA" name="specialOptsA" class="form-control" >
			<option disabled selected value > --Select an special school type--- </option>
			<option value="" >None </option>
			<option value="blind"> Blind </option>
			<option value="dnd"> Deaf and Dumb </option>
			<option value="mental" > Mentally Challenged </option>
		</select>
		<br><br>
		</div>
		<div id="specialB" style="display:none;">
		<label> Do you offer special needs classes?</label>
		<input type="radio" id="specClass1" name="specClass" value="Yes" onclick="OnClickRadio(this)"> Yes
		
		<input type="radio" id="specClass2"name="specClass" value="No" onclick="OnClickRadio(this)"
		 > No
		<br> <br>
		<p id="errorspecialOptsB"style="display:none; color:red; font-size:14px;" ></p>
		
		<div id="specialC" style="display:none;">
		<label> Type of Special Needs Classes: </label>
		<select id="specOptsID"name="specialOptsB" class="form-control" >
			<option disabled selected value > --Select a special class--- </option>
			<option value="" >None </option>
			<option value="blind" > Blind </option>
			<option value="dnd" > Deaf and Dumb </option>
 		</select>
		<br><br>
		</div>
		</div>
		<div id="text_area">
		<label> Boys/Girls/Mixed School? :<br> </label>
		<select id="bgmID" name="bgm" class="form-control" >
			<option disabled selected value > --Select an option--- </option>
			<option value="" >None </option>
			<option value="boys" > Boys </option>
			<option value="girls"> Girls </option>
			<option value="mixed" > Mixed </option>
		</select>
		<br><br>
	
		<br><br>
		
		<div class="container" style="height: 150px;
    background-color: lightyellow;">
		<label style="display:block;"> Tick the extracurriculum activities offered </label>
		<label style="font-weight:500;"><input type="checkbox" id= "musicID"name="extra_curr" value="Y"
		> Music</label></br>
		
		<label  style="font-weight:500;"> <input type="checkbox" id="frenchID" name="extra_curr" value="Y"
		
		>French</label></br>
		<label  style="font-weight:500;"><input type="checkbox" id="germanID" name="extra_curr" value="Y" 
		
		>German</label></br>
		<label  style="font-weight:500;"><input type="checkbox" id="chineseID"name="extra_curr" value="Y"
		
		>Chinese<br></label></br>
		<label style="font-weight:500;"><input type="checkbox" id="mArtsID"name="extra_curr" value="Y"
		
		>Martial Arts</label></br>
			
		
		</div>
		<br>
		<br>
		
		</div>	
	</div>	
    </div>	
	<!--- end of toggled form -->
	
		<input type="button" id="submit" class= "btn btn-success inputABC" value="Search" onclick="SearchDB()"
		style="width: 70px;"
		/>  
			</div>
			
			</form>
	<div style=" margin-top: 20px; margin-bottom: 15px;">		
	<input type="text" id="typedloc" class= "btn btn-default inputABC" value="" style="display:none;"/> 
	<input type="text" id="typedlocA" class= "btn btn-default inputABC" value="" style="display:none;"/> 

	<input type="text" id="fetched_geoloc" class= "btn btn-default inputABC" value="" style="display:none;"/> 
	<input type="text" id="fetched_geolocA" class= "btn btn-default inputABC" value="" style="display:none;"/> 
	
	<input type="button" id="map_view" class= "btn btn-default inputABC" value="View Results in Map" style="display:none;"/>
	<input type="button" id="results_view" class= "btn btn-default inputABC" value="View results in web view " style="display:none;"/>
	<p id="error" style="display:none;"> </p>
	<p id="msg" style="display:none; color:red;"> </p>
	</div>
	<div id="responsecontainer" class="jumbotron" style="display:none; margin:auto; width:60%;">
	
	</div>	
	 <div id="map" style="margin:auto; width:60%; display:none; height:500px"></div>
	 
	 </div>
	 <div style="height:100px">
	 
	 </div>
	 
	 
	 </body>

	 
<script>
      var map;
      var markers = [];
      var infoWindow;
	  var address;
	  
	  console.log(address);
console.log(window.location.search.substring(1));
var url=window.location.search.substring(1);
//make response container and map disappear on typing in curriculum
document.getElementById('advFormOpts').addEventListener('click', function () {
	
	if(this. style.color==="red"){
		this.style.color="green";
		this.style.background="yellow";
		console.log('green');
		//true;
	}
	else {
		this.style.color="red";
		this.style.background="";
		console.log('red');
		//true;
	}
	
		
});



document.getElementById('curriculum').addEventListener('change', function () {
	document.getElementById('responsecontainer').style.display="none";
	document.getElementById('map').style.display="none";
	document.getElementById('curriculum').focus();
});

//make the response container and map disappear when an option is selected in type of schools
document.getElementById('selectSpecial').addEventListener('change', function () {
	document.getElementById('responsecontainer').style.display="none";
	document.getElementById('map').style.display="none";
	document.getElementById('curriculum').focus();
});

//Advanced Form optiona

function myTracker(id){
console.log(id);
//'add_location1.php?name=' + name + '&address=' + address +
window.location.href='tracking.php?id=' + id;

}


//when a row is clicked in searched results

function myTracker(id){
console.log(id);
//'add_location1.php?name=' + name + '&address=' + address +
window.location.href='tracking.php?id=' + id;

}

if (url=location){
document.getElementById('place').focus();
}
 document.getElementById('myloc').addEventListener('click', function () {
	 this.style.color="blue";
	document.getElementById('place').disabled=true;
	document.getElementById('return_buttn').style.display="none";
	document.getElementById('restore_buttn').style.display="inline";
    if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(success);
		
		
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}); 

 

function success(pos) {
  var crd = pos.coords;

  console.log('Your current position is:');
  console.log(`Latitude : ${crd.latitude}`);
  console.log(`Longitude: ${crd.longitude}`);
  console.log(`More or less ${crd.accuracy} meters.`);
  // document.getElementById('').value;
  		document.getElementById('fetched_geoloc').value= crd.longitude;
		document.getElementById('fetched_geolocA').value= crd.latitude;
  
  getcurrentlocation(crd.latitude,crd.longitude);
};
// initialize map


//events occurring after view map is clicked		  
document.getElementById('map_view').addEventListener('click', function () {
console.log('Map view. Hello!');
		var buttn='button';
		console.log(buttn);
		getcurrentlocationmap(buttn);
});
//events after advanced options is clicked
function advancedOpt(){
document.getElementById('radius').style.display="block";
var radius = document.getElementById("radius");
radius.options[radius.options.selectedIndex].selected = true;
}

function collapseAdvoOpt(){
document.getElementById('radius').style.display="none";

}
//seatch for locations on map
	function getcurrentlocationmap(buttn){
	console.log('my button');
	console.log(buttn);
	var lngit=document.getElementById('typedloc').value;
	console.log('Map coordinates');
	var latit=document.getElementById('typedlocA').value;
	
	var longitude= document.getElementById('fetched_geoloc').value;
	var latitude = document.getElementById('fetched_geolocA').value;
  
	console.log(longitude);
	console.log(latitude);
	//console.log(latit);
	
		var radiusID=radius.options[radius.selectedIndex].value; 
		//var curriculum = document.getElementById('curriculum').value;
		var curr= curriculum.options[curriculum.selectedIndex].value; 
		var type=  selectSpecial.options[selectSpecial.selectedIndex].value; //value selected at select daycare/kindergatens/pri
		var rel=  religionID.options[religionID.selectedIndex].value; //value selected at religion
		var db= dayBoardID.options[dayBoardID.selectedIndex].value;
		var feeR= feeRangeID.options[feeRangeID.selectedIndex].value;
		var DFeeID= dayFeeID.options[dayFeeID.selectedIndex].value;
		var SOptsA= specialOptsA.options[specialOptsA.selectedIndex].value; //special needs schools
		var SOptB= specOptsID.options[specOptsID.selectedIndex].value; //SPECIAL NEEDS CLASSES
		var bgm= bgmID.options[bgmID.selectedIndex].value; //boys girls 
	//radio button
	var radio="";
		if (document.getElementById('specClass1').checked=== true){
			var radio= "Yes";
			console.log('CHECKBOX');
		}
		if (document.getElementById('specClass2').checked=== true){
			var radio= "NO";
			console.log('NO CHECKBOX');
			
		}
		console.log('RADIO VALUES');
		 console.log(radio);
		//checkboxes values
	
		if(document.getElementById('musicID').checked === true)
		{
			var music= "Y";
			console.log(music);
		}	
		if (document.getElementById('musicID').checked=== false)
		{
			var music= "";
			console.log('NO MUSIC');
			console.log(music);
		}
		
		console.log(music);
		//french checkbox
		if(document.getElementById('frenchID').checked === true)
		{
			var french= "Y";
			console.log('French');
			console.log(french);
		}	
		if (document.getElementById('frenchID').checked=== false)
		{
			var french= "";
			console.log('NO French');
			console.log(french);
		}
		
		//german checkbox
		if(document.getElementById('germanID').checked === true)
		{
			var german= "Y";
			console.log('German');
			console.log(german);
		}	
		if (document.getElementById('germanID').checked=== false)
		{
			var german= "";
			console.log('NO Germa');
			console.log(german);
		}
		//chinese checkbox
		if(document.getElementById('chineseID').checked === true)
		{
			var chinese= "Y";
			console.log('Chinese');
			console.log(chinese);
		}	
		if (document.getElementById('chineseID').checked=== false)
		{
			var chinese= "";
			console.log('NO Chinese');
			console.log(chinese);
		}
		
		// martial aets
		if(document.getElementById('mArtsID').checked === true)
		{
			var mArts= " ";
			console.log('mArts');
			console.log(mArts);
		}	
		
		if (document.getElementById('mArtsID').checked=== false)
		{
			var mArts= "";
			console.log('NO mArts');
			console.log(mArts);
		}

	
	
	if(latit!== " " && lngit !==""){
	var urlB ='curriculum=' + curr + '&lat=' + latit+ '&lng=' + lngit + '&radius=' + radiusID + '&type='+ type
					'&rel='+ rel +'&db='+ db + '&feeR='+ feeR + '&DFeeID='+ DFeeID + '&SOptsA='+ SOptsA + 
					'&SOptB='+ SOptB + '&bgm='+ bgm + '&french='+ french + '&german='+ german
					+ '&chinese='+ chinese + '&music='+ music + '&mArts='+  mArts +'&radio='+  radio
					;
		getschoolphpmap(urlB);
		}
	if(latitude!== "" && longitude !== ""){
	console.log('cuurent location latitude');
	var urlB ='curriculum=' + curr + '&lat=' + latitude+ '&lng=' + latitude + '&radius=' + radiusID + '&type='+ type
					'&rel='+ rel +'&db='+ db + '&feeR='+ feeR + '&DFeeID='+ DFeeID + '&SOptsA='+ SOptsA + 
					'&SOptB='+ SOptB + '&bgm='+ bgm + '&french='+ french + '&german='+ german
					+ '&chinese='+ chinese + '&music='+ music + '&mArts='+  mArts  +'&radio='+  radio ;
					
		getschoolphpmap(urlB);
		}
	}
	
//search for locations using geolocation
	function getcurrentlocation(latA, lngB){
		console.log(latA);
		console.log(lngB);
		//console.log(buttn);
		var curr= curriculum.options[curriculum.selectedIndex].value; 
		var type=  selectSpecial.options[selectSpecial.selectedIndex].value; //value selected at select daycare/kindergatens/pri
		var rel=  religionID.options[religionID.selectedIndex].value; //value selected at religion
		var db= dayBoardID.options[dayBoardID.selectedIndex].value;
		var feeR= feeRangeID.options[feeRangeID.selectedIndex].value;
		var DFeeID= dayFeeID.options[dayFeeID.selectedIndex].value;
		var SOptsA= specialOptsA.options[specialOptsA.selectedIndex].value; //special needs schools
		
		//var specClass1 = document.getElementById('specClass1').value; //radio buttons
		//var specClass2 = document.getElementById('specClass2').value;
		var SOptB= specOptsID.options[specOptsID.selectedIndex].value; //SPECIAL NEEDS CLASSES
		var bgm= bgmID.options[bgmID.selectedIndex].value; //boys girls 
		
		var radius = document.getElementById('radius').value;
		
		console.log('ALL VALUES');
		console.log(rel);
		console.log(db);
		console.log(feeR);
		console.log(DFeeID);
		console.log(SOptsA);
		console.log(SOptB);
		console.log(bgm);
			console.log('radio button value');
			
			//console.log(radio);
		//radio button specClass
		var radio="";
		if (document.getElementById('specClass1').checked=== true){
			var radio= "Yes";
			console.log('CHECKBOX');
		}
		if (document.getElementById('specClass2').checked=== true){
			var radio= "NO";
			console.log('NO CHECKBOX');
			
		}
		console.log('RADIO VALUES');
		 console.log(radio);
			
			
		//checkboxes values
	
		if(document.getElementById('musicID').checked === true)
		{
			var music= "Y";
			console.log(music);
		}	
		if (document.getElementById('musicID').checked=== false)
		{
			var music= "";
			console.log('NO MUSIC');
			console.log(music);
		}
		
		console.log(music);
		//french checkbox
		if(document.getElementById('frenchID').checked === true)
		{
			var french= "Y";
			console.log('French');
			console.log(french);
		}	
		if (document.getElementById('frenchID').checked=== false)
		{
			var french= "";
			console.log('NO French');
			console.log(french);
		}
		
		//german checkbox
		if(document.getElementById('germanID').checked === true)
		{
			var german= "Y";
			console.log('German');
			console.log(german);
		}	
		if (document.getElementById('germanID').checked=== false)
		{
			var german= "";
			console.log('NO Germa');
			console.log(german);
		}
		//chinese checkbox
		if(document.getElementById('chineseID').checked === true)
		{
			var chinese= "Y";
			console.log('Chinese');
			console.log(chinese);
		}	
		if (document.getElementById('chineseID').checked=== false)
		{
			var chinese= "";
			console.log('NO Chinese');
			console.log(chinese);
		}
		
		// martial aets
		if(document.getElementById('mArtsID').checked === true)
		{
			var mArts= "Y";
			console.log('mArts');
			console.log(mArts);
		}	
		if (document.getElementById('mArtsID').checked=== false)
		{
			var mArts= "";
			console.log('NO mArts');
			console.log(mArts);
		}
		
		
		console.log('CHECKBOXES');
		console.log(french);
		console.log(german);
		console.log(chinese);		
		console.log(music);
		console.log(mArts);
		
		console.log('ALL VALUES');
		console.log(rel);
		console.log(db);
		console.log(feeR);
		console.log(DFeeID);
		console.log(SOptsA);
		console.log(SOptB);
		console.log(bgm);
		
		//creating current location url
		if(latA && lngB){

		console.log(latA);
		console.log(lngB);
		console.log('Hello, Using Current location');
		 document.getElementById('msg').style.display="block";
		document.getElementById('msg').innerHTML= ' Your location has been detected. ';
		var urlA ='curriculum=' + curr + '&lat=' + latA+ '&lng=' + lngB + '&radius=' + radius + '&type='+ type +
					'&rel='+ rel +'&db='+ db + '&feeR='+ feeR + '&DFeeID='+ DFeeID + '&SOptsA='+ SOptsA + 
					'&SOptB='+ SOptB + '&bgm='+ bgm + '&french='+ french + '&german='+ german
					+ '&chinese='+ chinese + '&music='+ music + '&mArts='+  mArts +'&radio='+  radio
			;
		getschoolphp(urlA);
		//removeinputBox();
		}
		else {
		//creating typed location url
		document.getElementById('typedloc').value=latA.lng();
		document.getElementById('typedlocA').value=latA.lat();
		console.log(latA.lat());
		console.log(latA.lng());
		console.log('It is me! Using typed location');
		
		var urlA ='curriculum=' + curr + '&lat=' + latA+ '&lng=' + lngB + '&radius=' + radius + '&type='+ type +
					'&rel='+ rel +'&db='+ db + '&feeR='+ feeR + '&DFeeID='+ DFeeID + '&SOptsA='+ SOptsA + 
					'&SOptB='+ SOptB + '&bgm='+ bgm + '&french='+ french + '&german='+ german
					+ '&chinese='+ chinese + '&music='+ music + '&mArts='+  mArts  +'&radio='+  radio
					;
		getschoolphp(urlA);
		}
		}
		

//what happens when you click remove input box		}
function removeinputBox(){
//document.getElementById('remove_buttn').style.display="none";
var place= document.getElementById('place');
var typedloc = document.getElementById('typedloc');
var typedlocA=  document.getElementById('typedlocA');
place.style.display="none";
place.value="";
typedloc.value= "";
typedlocA.value="";
//document.getElementById('msg').style.display="none";
document.getElementById('return_buttn').style.display="inline";
document.getElementById('remove_buttn').style.display="none";
document.getElementById('myloc').style.display="inline";
document.getElementById('msg').display="none";


}

function returninputBox(){

var place= document.getElementById('place');
place.style.display="inline";

}
//on the event that you don't want to use geolocatio anymore				
function restoreInputs(){
document.getElementById('myloc').style.color="";
document.getElementById('msg').innerHTML="No location entered of detected"
document.getElementById('fetched_geoloc').value="";
document.getElementById('fetched_geolocA').value="";
document.getElementById('place').style.display="inline";
document.getElementById('place').disabled = false;
document.getElementById('remove_buttn').style.display="none";
document.getElementById('restore_buttn').style.display="none";
;

}
//what happens when you click submit		
 function SearchDB () {
		//document.getElementById('return_buttn').style.display="none";
		document.getElementById('msg').style.display="none";
		
		
		address = document.getElementById('place').value;
		var fetched_geoloc=  document.getElementById('fetched_geoloc').value;
		var fetched_geolocA=  document.getElementById('fetched_geolocA').value;
		var typedloc=  document.getElementById('typedloc').value;
		var typedlocA=  document.getElementById('typedlocA').value;
		//var address = document.getElementById('place').value;
		//document.getElementById('msg').style.display="none";
		
		document.getElementById('map').style.display="none";
		document.getElementById('responsecontainer').style.display="none";
		document.getElementById('map_view').style.display="none";
		document.getElementById('results_view').style.display="none";
			
		
		var curriculum = document.getElementById('curriculum').value;
		var type=  selectSpecial.options[selectSpecial.selectedIndex].value; //value selected at select daycare/kindergatens/pri
		console.log(address);
		console.log(type);
		console.log(curriculum);
		console.log(fetched_geoloc);
		
		//alert(address);
		//first time search.  No typed location yet. No fetched location by geolocation
		 if(address!== ""){
				console.log('here3');
				document.getElementById('remove_buttn').style.display="inline";
				document.getElementById('myloc').style.display="none";
				var geocoder = new google.maps.Geocoder();
				 geocoder.geocode({'address': address}, function(results, status) {
				   if (status == google.maps.GeocoderStatus.OK) {
					//alert(results[0].geometry.location);
					var loc=results[0].geometry.location;
					console.log(loc.lat());	
					console.log(loc.lng());
					console.log(curriculum);
					console.log('here3');
					//var urlA ='curriculum=' + curriculum + '&lat=' + loc.lat() + '&lng=' + loc.lng();
					//console.log(urlA);
					//getschoolphp(urlA);
					getcurrentlocation(loc); 
					} else {
					document.getElementById('error').style.display="none";
					 document.getElementById('error').innerHTML= address + ' location not found. Please another address';
					}
		
				});}
				
				
		//if typed location is set and fetched location is not set		
	
			 
		//if there a fetched location and no typed location	 
			 if(fetched_geoloc !== "" && fetched_geolocA !== ""  ){
			
			 console.log('Using fetched location');
			 getcurrentlocation(fetched_geolocA, fetched_geoloc);
			 }
			 
		//	 
			 
			 if(address === "" && fetched_geoloc === "" && typedloc ==="" && typedlocA === ""){ 
			
			alert('Enter a location');
			 }
			
           }
		   
		   
		   
         
		
		
		   
	function getschoolphp(urlA){
	console.log(urlA);
		$.ajax(
			{
			type:'GET',
			url: "get_school.php",
			data:urlA,
			success: function(response){
				
				console.log('This is a response as a table');
					document.getElementById('844_TYPE').style.display="inline";
					document.getElementById('locationBox').style.position="relative";
					//document.getElementById('locationBox').style.top="-35px";
					
					//locationBox
					//$("#844_TYPE").show();
					$("#selectSpecial").focus();
					$("#responsecontainer").show();
					$("#map_view").show();
					$("#responsecontainer").html(response);
					   
					 //styliing the search box  
					document.getElementById('submit').style.position="relative";
					document.getElementById('submit').style.left="609px";
					document.getElementById('submit').style.top="-68px";
					
					//style the h1
					document.getElementById('h1Welcome').style.textAlign="center";
				
						}
					});
	
	}
		function getschoolphpmap(urlB){
	console.log(urlB);
		$.ajax(
			{
			type:'GET',
			url: "get_school.php",
			data:urlB,
			success: function(data){
				document.getElementById('responsecontainer').style.display="none";
				document.getElementById('map').style.display="block";
				document.getElementById('map_view').style.display="none";
				document.getElementById('results_view').style.display="block";
				initMap();
				printMap(data);

					}
					});
	
	}
	
function initMap() {
          var sydney = {lat: -1.2920, lng: 36.8219};
          map = new google.maps.Map(document.getElementById('map'), {
            center: sydney,
            zoom: 13,
            mapTypeId: 'roadmap',
            mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU}
          });
		  infoWindow = new google.maps.InfoWindow();

		  }
		  
function printMap(data){
		
		//var xml = parseXml(data, responseCode);
          var xml = data;
           var markerNodes = xml.documentElement.getElementsByTagName("marker");
           var bounds = new google.maps.LatLngBounds();
		   if(markerNodes.length==0){
				window.alert('Not found');
				
		   }else{
		   
			for (var i = 0; i < markerNodes.length; i++) {
             var id = markerNodes[i].getAttribute("id");
             var name = markerNodes[i].getAttribute("name");
             var address = markerNodes[i].getAttribute("address");
             var distance = parseFloat(markerNodes[i].getAttribute("distance"));
			 	console.log(distance);
             var latlng = new google.maps.LatLng(
                  parseFloat(markerNodes[i].getAttribute("lat")),
                  parseFloat(markerNodes[i].getAttribute("lng")));
			var type = markerNodes[i].getAttribute("type");
			
             //createOption(name, distance, i);
             createMarker(latlng, name, address, type);
             bounds.extend(latlng);
			
			map.fitBounds(bounds);
			
			document.getElementById('results_view').addEventListener('click', function () {
				document.getElementById('map').style.display="none";
				document.getElementById('responsecontainer').style.display="block";
			    document.getElementById('map_view').style.display="block";
				document.getElementById('results_view').style.display="none";
			
			});
		   
		   }
		   }
		   }
  var customLabel = {
        kindergaten: {
          label: 'K'
        },
        primary: {
          label: 'P'
        }
      };
	    function createMarker(latlng, name, address, type) {
          var html = "<b>" + name + "</b> <br/>" + address;
		  var icon = customLabel[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: latlng,
			label:icon.label
          });
          google.maps.event.addListener(marker, 'click', function() {
            infoWindow.setContent(html);
            infoWindow.open(map, marker);
          });
          markers.push(marker);
        }		  




console.log(url);

</script>
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcRxdnXCuxQQuq01-UsXv57-aHgLowxcY&callback=initMap">       
</script>

	




</html>