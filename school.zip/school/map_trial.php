<?php
require('includes\headers1.php');

?>


<!DOCTYPE html >
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
	<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <title>Creating a Store Locator on Google Maps</title>
  <style>
    /* Always set the map height explicitly to define the size of the div
     * element that contains the map. */
    #map {
      height: 100%;
    }
    /* Optional: Makes the sample page fill the window. */
    html, body {
      height: 100%;
      margin: 0;
      padding: 0;
    }
 </style>
  </head>
  <body style="margin:0px; padding:0px;" onload="initMap()">
    <div>
         
	<div style="margin-top:60px">	
		<button type= "button"onclick="getLocation()">For you</button>
    </div>
    <div><select id="locationSelect" style="width: 10%; visibility: hidden; text-color:red; "></select></div>
    <div id="map" style="width:1500px; height: 500px"></div>
	</div>
    <script>
      var map;
      var markers = [];
      var infoWindow;
      var locationSelect;
window.onload = function() {
getLocation();
console.log('hello');
}
 function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
		
	
		
		
		 
    } else { 
        x.innerHTML = "Geolocation is not supported by this browser.";
    }
}
        function initMap() {
          var sydney = {lat: -1.2920, lng: 36.8219};
          map = new google.maps.Map(document.getElementById('map'), {
            center: sydney,
            zoom: 11,
            mapTypeId: 'roadmap',
            mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU}
          });
          infoWindow = new google.maps.InfoWindow();

        

          locationSelect = document.getElementById("locationSelect");
          locationSelect.onchange = function() {
            var markerNum = locationSelect.options[locationSelect.selectedIndex].value;
            if (markerNum != "none"){
              google.maps.event.trigger(markers[markerNum], 'click');
            }
          };
        }
		
      

       function clearLocations() {
         infoWindow.close();
         for (var i = 0; i < markers.length; i++) {
           markers[i].setMap(null);
         }
         markers.length = 0;

         locationSelect.innerHTML = "";
         var option = document.createElement("option");
         option.value = "none";
         option.innerHTML = "See all results:";
         locationSelect.appendChild(option);
       }
	

	function showPosition(position) {
 
	console.log(position.coords.latitude);
	console.log(position.coords.longitude);
	searchLocationsNear(position.coords.latitude, position.coords.longitude);
	
	
	var pos={
		lat:position.coords.latitude,
		lng: position.coords.longitude
	};
			var markers= new google.maps.Marker({
				position:pos,
				map:map,
			})
			infoWindow.close();	
            infoWindow.setPosition(pos);
            infoWindow.setContent('<b style="color: blue;">Your location<b>');
            infoWindow.open(map,markers);
            map.setCenter(pos);
			markers.addListener('click', function(){
			infoWindow.open(map,markers),
			infoWindow.setContent('<b style="color: blue;">Your location<b>')
			
			});
			
			
          
        } 
	
	







       function searchLocationsNear(lng, lat) {
         clearLocations();

       	  console.log(lng);
		   console.log(lat);
		 var lat=lat;
		 var lng= lng;
		 
		 var searchUrl = "map1.php?lat=" + lng + "&lng=" + lat;
			console.log(searchUrl);
		  
         downloadUrl(searchUrl, function(data, responseCode) {
           var xml = parseXml(data, responseCode);
           var markerNodes = xml.documentElement.getElementsByTagName("marker");
           var bounds = new google.maps.LatLngBounds();
		   if(markerNodes.length==0){
				window.alert('Not found');
				initMap();
		   }else{
		   
			for (var i = 0; i < markerNodes.length; i++) {
             var id = markerNodes[i].getAttribute("id");
             var name = markerNodes[i].getAttribute("name");
             var address = markerNodes[i].getAttribute("address");
             var distance = parseFloat(markerNodes[i].getAttribute("distance"));
			 	console.log(distance);
             var latlng = new google.maps.LatLng(
                  parseFloat(markerNodes[i].getAttribute("lat")),
                  parseFloat(markerNodes[i].getAttribute("lng")));
			var type = markerNodes[i].getAttribute("type");
			
             createOption(name, distance, i);
             createMarker(latlng, name, address, type, id);
             bounds.extend(latlng);
          

		   
		   }
		   
           map.fitBounds(bounds);
		   
		   
           locationSelect.style.visibility = "visible";
           locationSelect.onchange = function() {
             var markerNum = locationSelect.options[locationSelect.selectedIndex].value;
             google.maps.event.trigger(markers[markerNum], 'click');
           }
		    }
		   
         }
		);
       }
		var customLabel = {
        kindergaten: {
          label: 'K'
        },
        primary: {
          label: 'P'
        },
		special: {
		  label: 'P'
		},
		daycare: {
		  label: 'D'
		}
      };

       function createMarker(latlng, name, address, type, id) {
          var html = "<b>" + name + "</b> <br/>" + address +"</br><a href='tracking.php?id="+id+"' style='color:red;'>View Profile</a>";
		  var icon = customLabel[type] || {};
          var marker = new google.maps.Marker({
            map: map,
            position: latlng,
			label:icon.label
          });
          google.maps.event.addListener(marker, 'click', function() {
            infoWindow.setContent(html);
            infoWindow.open(map, marker);
          });
          markers.push(marker);
        }

       function createOption(name, distance, num) {
          var option = document.createElement("option");
          option.value = num;
          option.innerHTML = name;
          locationSelect.appendChild(option);
       }

       function downloadUrl(url, callback) {
          var request = window.ActiveXObject ?
              new ActiveXObject('Microsoft.XMLHTTP') :
              new XMLHttpRequest;

          request.onreadystatechange = function() {
            if (request.readyState == 4) {
              request.onreadystatechange = doNothing;
              callback(request.responseText, request.status);
			   //alert(request.responseText);
			    
            }
          };

          request.open("GET", url, true);
          request.send(null);
       }

       function parseXml(str) {
          if (window.ActiveXObject) {
            var doc = new ActiveXObject('Microsoft.XMLDOM');
            doc.loadXML(str);
            return doc;
          } else if (window.DOMParser) {
            return (new DOMParser).parseFromString(str, 'text/xml');
          }
       }

       function doNothing() {}
  </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcRxdnXCuxQQuq01-UsXv57-aHgLowxcY&callback=initMap">                                                                                     
    </script>
  </body>
</html>