<?php

require("db.php");
require("includes\headerNavigationBar.php");

	$id = $_SESSION['User_ID'];
	$result = mysqli_query($conn,"SELECT users.*, location.* FROM users 
							INNER JOIN location ON users.User_ID=location.User_ID 
							WHERE users.User_ID = '$id' AND location.User_ID='$id' ");
	
	
	$row  = mysqli_fetch_array($result);
	
	//echo $id;
	

?>


<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
	<link rel="stylesheet" type="text/css" href="includes\map.css">

    <title>Edit Location</title>
  </head>
  <body>
	<h2 class="center"> Update location </h2>
	<p class="text-primary center"><a href ="http://localhost/school/school_homepage.php">Home</a> 
	<span class="glyphicon glyphicon-chevron-right"></span> <a href ="http://localhost/school/show_location.php">Current location </a>
	<span class="glyphicon glyphicon-chevron-right"></span> <a href ="">Edit location </a>
	</p>
	</br>
    <div id="map" class="center"></div>
    <div id="form" class="center">
      <table>
      <tr><td>School Name:</td> <td><input type='text' id='name' value ="<?php echo $row['School_name']; ?>" disabled/> </td> </tr>
      <tr><td>Address:</td> <td><input type='text' id='address' placeholder="Enter your address"/> </td> </tr>
      <tr><td>Type of school :</td> <td><select id='type' disabled> 
			<option disabled selected value > --Select an option--- </option>
			<option value="daycare" <?php if ($row['type']== 'daycare'){ echo"selected"; }; ?>> DayCare</option>
			<option value="kindergaten" <?php if ($row['type']== 'kindergaten'){ echo"selected";}; ?>> Kindergaten </option>
			<option value="primary" <?php if ($row['type']== 'primary'){ echo"selected"; }; ?>> Primary School </option>
			<option value="special" <?php if ($row['type']== 'special'){ echo"selected"; }; ?>> Special Needs School </option>
                 </select> </td></tr>
                 <tr><td></td><td><input type='button' value='Save' onclick='saveData()'/></td></tr>
      </table>
    </div>
    <p class="center" style="color:red;"> Double click on the map to pin your location </p> 
	<!--<div id="message">Location saved</div>-->
    <script>
	
	document.getElementById('address').focus();
      var map;
      var marker;
      var infowindow;
      var messagewindow;

      function initMap() {
        var california = {lat: -1.2920, lng: 36.8219};
        map = new google.maps.Map(document.getElementById('map'), {
          center: california,
          zoom: 13
        });

        infowindow = new google.maps.InfoWindow({
          content: document.getElementById('form')
        });

        messagewindow = new google.maps.InfoWindow({
          content: document.getElementById('message')
        });
 
        google.maps.event.addListener(map, 'click', function(event) {
          marker = new google.maps.Marker({
            position: event.latLng,
            map: map
          });


          google.maps.event.addListener(marker, 'click', function() {
            infowindow.open(map, marker);
          });
        });
      }

      function saveData() {
        var name = escape(document.getElementById('name').value);
        var address = escape(document.getElementById('address').value);
        var type = document.getElementById('type').value;
        var latlng = marker.getPosition();
        var url = 'add_location1.php?name=' + name + '&address=' + address +
                  '&type=' + type + '&lat=' + latlng.lat() + '&lng=' + latlng.lng();

        downloadUrl(url, function(data, responseCode) {

          if (responseCode == 200 && data.length <= 1) {
            infowindow.close();
            messagewindow.open(map, marker);
          }
        });
      }

      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request.responseText, request.status);
			 alert(request.responseText);
			 window.location.href = "show_location.php";
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing () {
      }

    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDj8AVejS_y_93KkYOc0Tsq86SRNk5l7lM&callback=initMap">
    </script>
  </body>
</html>