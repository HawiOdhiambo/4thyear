<?php
	

include_once("db.php");
	if(isset($_GET['delete']))
	{
		$id=$_GET['delete'];
	    $sql= "DELETE FROM school WHERE  SCH_ID='$id'";
		
		if (mysqli_query($conn, $sql)) 
			header("location:view_schools.php?success1");
		else 
			header("location:view_schools.php?error");
		
	}

?>