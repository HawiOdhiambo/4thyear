<?php
require("db.php");
echo"you are here";
if(isset( $_GET['id'])){

$id = $_GET['id'];
	
}

$sql="INSERT INTO track_clicks (userID, date)
VALUES ('$id', NOW())";

if (mysqli_query($conn, $sql)){
			echo"successful";
			header("location:school_profile.php?id=$id");
	} else{ 
			
			header("location:get_school_home.php?error");
	}
?>