<?php
require("db.php");
// Get parameters from URL

$center_lat = $_GET["lat"];
$center_lng = $_GET["lng"];
//$radius = $_GET["radius"];
$radius = 3;

/*
$center_lat = -1;

$center_lng = 36;
$radius = 3;
*/
/*$center_lat = -1.293073;

$center_lng = 36.821507;
$radius = 3;
*/

// Start XML file, create parent node
$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);

$type=""; 


// Search the rows in the markers table
$query = sprintf("SELECT users.School_name, users.User_ID , location.address, location.type, location.lat, location.lng, (  6371 * acos( cos( radians('%s') ) * cos( radians( lat ) ) * cos( radians( lng ) - radians('%s') ) + sin( radians('%s') ) * sin( radians( lat ) ) ) ) AS distance FROM location INNER JOIN users ON location.User_ID=users.User_ID HAVING distance < '%s' ORDER BY distance LIMIT 0 , 20",
  mysqli_real_escape_string( $conn, $center_lat),
  mysqli_real_escape_string($conn, $center_lng),
  mysqli_real_escape_string($conn, $center_lat),
  mysqli_real_escape_string($conn, $radius));
   //mysqli_real_escape_string($conn, $type)
$result = mysqli_query($conn, $query);
$result = mysqli_query($conn, $query);
if (!$result) {
  die("Invalid query: " . mysqli_error($conn));
}
header("Content-type: text/xml charset=utf-8");
// Iterate through the rows, adding XML nodes for each
while ($row = @mysqli_fetch_assoc($result)){
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
   $newnode->setAttribute("name", $row['School_name']);
  $newnode->setAttribute("id", $row['User_ID']);
  $newnode->setAttribute("type", $row['type']);
  $newnode->setAttribute("address", $row['address']);
  $newnode->setAttribute("lat", $row['lat']);
  $newnode->setAttribute("lng", $row['lng']);
  $newnode->setAttribute("distance", $row['distance']);
}
echo $dom->saveXML();
?> 