<style>
	#recommSch:hover {
    cursor: pointer;
	color:red;
}
.inputColor{
	font-weight:700;
}
label.{
	color: blue;
}

</style>

<?php

//require("db.php");
require('includes\headers1.php');

if(isset( $_GET['id'])){
$id = $_GET['id'];

}
else {
	echo"error";
}


$result = mysqli_query($conn,"SELECT users.School_name, school_details.Curriculum, school_details.BGM, location.type,
							school_details.Religion, extra_curriculum.*, school_details.SpecialType, school_details.SpecialRadio,
							school_details.SpecialClass, school_details.day_board , school_details.motto, school_details.FeeRange,
							school_details.dayFee
							FROM users 
									INNER JOIN school_details ON users.User_ID=school_details.User_ID 
									INNER JOIN location ON school_details.User_ID=location.User_ID 
									INNER JOIN extra_curriculum ON location.User_ID=extra_curriculum.User_ID 
									WHERE users.User_ID = '$id' AND school_details.User_ID='$id' AND location.User_ID='$id'
									AND extra_curriculum.User_ID ='$id'  
									");
	
	
	$row  = mysqli_fetch_array($result);
	
	echo $id;
	 echo $row['type'];
	 
	  echo $row['Religion']; 
	  $rel=$row['Religion']
?>

 

	
	
	 <?php


	  

	
?>	


<div class="container-fluid text-center" style="margin-top: 100px;">    
  <div class="row content">
    
     <div class="col-sm-2 sidenav">
	<div style="display:inline;">
<label>Users have viewed recently </label>
     <?php
	 $sql="SELECT users.School_name, school_details.Curriculum, track_clicks.link_id, track_clicks.userID, MAX(date)
	 FROM track_clicks 
			  INNER JOIN school_details ON track_clicks.userID=school_details.User_ID 
			  INNER JOIN users ON school_details.User_ID=users.User_ID
	 
	 WHERE userID != $id GROUP BY userID ORDER BY MAX(date) LIMIT 5 " ;
	 $query=mysqli_query($conn, $sql);
	
	 while($r = mysqli_fetch_assoc($query)){
		 // "<tr class='success row' onclick='myTracker(" .$row['User_ID']. ")' >
		echo '<div id="recommSch" class="container" style="width:50%;  background-color: lightyellow;" onclick="myTracker(' .$r['userID']. ')">';
		//echo $r['userID'], '</br> ';
		echo  $r['School_name'] ,'</br> ';
		echo  $r['Curriculum'];
		echo "</br><br> </div></br>";
		
	 }
	 ?>
	 </div style="display:inline;">
	 <div>
	 <label>Users with  the similar religious values</label>
     <?php
	 $sql="SELECT users.School_name, school_details.Curriculum,school_details.Religion, school_details.User_ID
	 FROM users 
	 INNER JOIN school_details ON school_details.User_ID=users.User_ID
	 WHERE school_details.User_ID != 57 AND users.User_ID != $id AND school_details.Religion LIKE'%%$rel%'";
	 $query=mysqli_query($conn, $sql);
	
	 while($r = mysqli_fetch_assoc($query)){
		 // "<tr class='success row' onclick='myTracker(" .$row['User_ID']. ")' >
		echo '<div id="recommSch" class="container" style="width:50%;  background-color: lightyellow;" onclick="myTracker(' .$r['User_ID']. ')">';
		echo $r['Religion'], '</br> ';
		echo  $r['School_name'] ,'</br> ';
		echo  $r['Curriculum'];
		echo "</br><br> </div></br>";
		
	 }
	 ?>
	 
    </div>
    <div class="col-sm-8 text-left"> 
	<div id="jumbo" class="jumbotron" style="border-color: #c6c1c1; border-style: solid; background-color: rgba(255, 182, 193, 0.22);     width: 650px;
    margin: auto;      top: -1047px;
    position: relative;
    left: 246px; ">
	<p class="text-primary center"><a href ="http://localhost/school/get_school_home.php">Home</a> <span class="glyphicon glyphicon-chevron-right"></span> <a href ="">School Profile </a></p>
			
	
		<h2> <span style="display:inline;  font-weight: bold; color: #00cc00; text-align:center;">
		<?php echo strtoupper($row['School_name']); ?></span> SCHOOL PROFILE
		</h2>
	
	
	
<form class="form form-horizontal" action="edit2.php"  onsubmit="return validateForm()" method="GET" name="school_details_form">
	 <div class="form-group">	
		
		
		<input type="hidden" name="User_ID" id="SCH_ID" value ="<?php echo $id; ?>">
		<br>
		<p id="errorSCHname"style="display:none;  font-size:14px;" ></p>
		<label>School_name:<br></label>
		<input class="form-control"type="text" style="font-weight:700;"id="sch_name" name="new_school_name" value ="<?php echo $row['School_name']; ?>" disabled >
		<br>
		 
		<label> Curriculum:<br> </label>
		<select name="curriculum" class="form-control inputColor" disabled >
			<option disabled selected value > --Select an option--- </option>
			<option value="IGCSE" <?php if ($row['Curriculum']== 'IGCSE'){ echo"selected";}; ?>> IGCSE </option>
			<option value="844" <?php if ($row['Curriculum']== '844'){ echo"selected"; }; ?>> 844 </option>
			<option value="IGCSE_and_844" <?php if ($row['Curriculum']== 'IGCSE_and_844'){ echo"selected"; }; ?> > IGCSE and 844 </option>
		</select>
			<br><br>
		<label> Day/Boarding? :<br> </label>
		<select  name="day_board" class="form-control" disabled style="font-weight:400;">
			<option disabled selected value > --Select an option--- </option>
			<option value="day" <?php if ($row['day_board']== 'day'){ echo"selected"; }; ?>> Day</option>
			<option value="boarding" <?php if ($row['day_board']== 'boarding'){ echo"selected";}; ?>> Boarding </option>	
		</select>
		<br><br>
			
		<label> Daycare/Kindergaten/Primary School/Special Needs School? :<br> </label>
		<select id="selectSpecial" name="type" class="form-control" onload="special(selectSpecial.value);"disabled style="font-weight:400;">
			<option disabled selected value > --Select an option--- </option>
			<option value="daycare" <?php if ($row['type']== 'daycare'){ echo"selected"; }; ?>> DayCare</option>
			<option value="kindergaten" <?php if ($row['type']== 'kindergaten'){ echo"selected";}; ?>> Kindergaten </option>
			<option value="primary" <?php if ($row['type']== 'primary'){ echo"selected"; }; ?>> Primary School </option>
			<option value="special" <?php if ($row['type']== 'special'){ echo"selected"; }; ?>> Special Needs School </option>
		</select>
		<br><br>
		
		<div id="feeDiv" disabled>
		<label> Fee Range: </label>
		<select id="feeRangeID" name="FeeRange" class="form-control"  disabled style="font-weight:400;">
			<option disabled selected value > --Select a fee range below--- </option>
			<option value="free" <?php if ($row['FeeRange']== 'less10'){ echo"selected";}; ?>> free </option>
			<option value="less10" <?php if ($row['FeeRange']== 'less10'){ echo"selected";}; ?>> less KSH 10,000 </option>
			<option value="10_20" <?php if ($row['FeeRange']== '10_20'){ echo"selected"; }; ?>> KSH 10,000 20,000</option>
			<option value="21_30" <?php if ($row['FeeRange']== '21_30'){ echo"selected"; }; ?>> KSH 21-30,000 </option>
			<option value="31_40" <?php if ($row['FeeRange']== '31_40'){ echo"selected"; }; ?>> KSH 31-40,000 </option>
			<option value="41_50" <?php if ($row['FeeRange']== '41_50'){ echo"selected"; }; ?>> KSH 41,000-50,000 </option>
			<option value="51_60" <?php if ($row['FeeRange']== '51_60'){ echo"selected"; }; ?>> KSH 51,000-60,000</option>
			<option value="61_70" <?php if ($row['FeeRange']== '61_70'){ echo"selected"; }; ?>> KSH 61,000-70,000 </option>
			<option value="71_80" <?php if ($row['FeeRange']== '71_80'){ echo"selected"; }; ?>> KSH 71,000-80,000 </option>
			<option value="81_90" <?php if ($row['FeeRange']== '81_90'){ echo"selected"; }; ?>> KSH 81,000-90,000 </option>
			<option value="91_100" <?php if ($row['FeeRange']== '91_100'){ echo"selected"; }; ?>>KSH 91,000-100,000</option>
			<option value="abv100" <?php if ($row['FeeRange']== 'abv100'){ echo"selected"; }; ?>> ABOVE 100,000 </option>
		</select>
		<br><br>
		</div>
		
		
		<div id="feeDivDayC"  disabled>
		<label> Day care Fee per day: </label>
			<select id="dayFeeID" name="dayFee" class="form-control" disabled style="font-weight:400;" >
			<option disabled selected value > --Select a fee range below--- </option>
			<option value="less5" <?php if ($row['dayFee']== 'less5'){ echo"selected";}; ?>> less 500  per day </option>
			<option value="5_10" <?php if ($row['dayFee']== '5_10'){ echo"selected";}; ?>>KSH 500- 1,000  per day </option>
			<option value="10_30" <?php if ($row['dayFee']== '10_30'){ echo"selected"; }; ?>>KSH 1,000 - 2000  per day</option>
			<option value="30_50" <?php if ($row['dayFee']== '30_50'){ echo"selected"; }; ?>> KSH 3,000- 5,000  per day </option>
			<option value="50_100" <?php if ($row['dayFee']== '50_100'){ echo"selected"; }; ?>> KSH 5,000-10,000  per day </option>
			<option value="abv100" <?php if ($row['dayFee']== 'abv100'){ echo"selected"; }; ?>> ABOVE 10,000  per day</option>
			
		</select>
		
		
		<br><br>
		</div>
		
		
		
		<p id="errorspecialOptsA"style=" color:red; font-size:14px;" ></p>
		<div id="specialA" style="display:none;"disabled>
		<label> Type of Special Needs Schools: </label>
		<select id="specialOptsA" name="specialOptsA" class="form-control"style="font-weight:400;" disabled>
			<option disabled selected value > --Select an special school type--- </option>
			<option value="blind" <?php if ($row['SpecialType']== 'blind'){ echo"selected";}; ?>> Blind </option>
			<option value="dnd" <?php if ($row['SpecialType']== 'dnd'){ echo"selected"; }; ?>> Deaf and Dumb </option>
			<option value="mental" <?php if ($row['SpecialType']== 'mental'){ echo"selected"; }; ?>> Mentally Challenged </option>
		</select>
		<br><br>
		</div>
		
		<div id="specialB" >
		<label> Do you offer special needs classes?</label>
		<input type="radio" id="specClass1" name="specClass" value="Yes" onload="OnClickRadio(this)"
		<?php if ($row['SpecialRadio']== 'Yes'){ echo"checked";}; ?> disabled > Yes
		
		<input type="radio" id="specClass2"name="specClass" value="No" onload="OnClickRadio(this)"
		 <?php if ($row['SpecialRadio']== 'No'){ echo"checked";}; ?> disabled> No
		<br> <br>
		<p id="errorspecialOptsB"style=" color:red; font-size:14px;" ></p>
		
		
		<label> Type of Special Needs Classes: </label>
		<select id="specialOptB"name="specialOptsB" class="form-control" disabled style="font-weight:400;">
			<option disabled selected value > --Select a special class--- </option>
			<option value="blind" <?php if ($row['SpecialClass']== 'blind'){ echo"selected";}; ?>> Blind </option>
			<option value="dnd" <?php if ($row['SpecialClass']== 'dnd'){ echo"selected"; }; ?>> Deaf and Dumb </option>
 		</select>
		<br><br>
	
		</div>
		<div id="text_area">
		<label> Boys/Girls/Mixed School? :<br> </label>
		<select name="bgm" class="form-control" disabled style="font-weight:400;" >
			<option disabled selected value > --Select an option--- </option>
			<option value="boys" <?php if ($row['BGM']== 'boys'){ echo"selected";}; ?>> Boys </option>
			<option value="girls" <?php if ($row['BGM']== 'girls'){ echo"selected"; }; ?>> Girls </option>
			<option value="mixed" <?php if ($row['BGM']== 'mixed'){ echo"selected"; }; ?>> Mixed </option>
		</select>
		<br><br>
		<label> Religious values :<br> </label>
		
		<input list="religions" id="rel"name="religion" class="form-control" placeholder="Enter your religous values if any or selcet one from dropdown"
		value="<?php  echo $row['Religion']; ?>" style="width:500px" disabled style="font-weight:400;" >
		<datalist id="religions">
			<option disabled selected value > --Select an option--- </option>
			<option value="christian" <?php if ($row['Religion']== 'christian'){ echo"selected";}; ?>> Christian </option>
			<option value="catholic" <?php if ($row['Religion']== 'catholic'){ echo"selected"; }; ?>> Catholic </option>
			<option value="muslim" <?php if ($row['Religion']== 'muslim'){ echo"selected"; }; ?>> Muslim </option>
		</datalist> 
		<i class="glyphicon glyphicon-remove" id="restore_buttn" onclick="restoreInputs()" title="clear religious values" style="left: 600px; top: -30px; display:none;" disabled> </i>
	
		<br><br>
		
		<div class="container" style="height: 150px;
    background-color: lightyellow;">
		<label style="display:block;"> Tick the extracurriculum activities offered </label>
		<label style="font-weight:500;"><input type="checkbox" name="extra_curr0" value="Y"
		<?php if ($row['Music']== 'Y'){ echo"checked";}; ?> disabled> Music</label></br>
		
		<label  style="font-weight:500;"> <input type="checkbox" name="extra_curr1" value="Y"
		<?php if ($row['French']== 'Y'){ echo"checked";}; ?> disabled
		>French</label></br>
		<label  style="font-weight:500;"><input type="checkbox" name="extra_curr2" value="Y" 
		<?php if ($row['German']== 'Y'){ echo"checked";}; ?> disabled
		>German</label></br>
		<label  style="font-weight:500;"><input type="checkbox" name="extra_curr3" value="Y"
		<?php if ($row['Chinese']== 'Y'){ echo"checked";}; ?> disabled
		>Chinese<br></label></br>
		<label style="font-weight:500;"><input type="checkbox" name="extra_curr4" value="Y"
		<?php if ($row['M_arts']== 'Y'){ echo"checked";}; ?> disabled
		>Martial Arts</label></br>
			
		
		</div>
		<br>
		<br>
		<label> Motto: </Motto></label>
		
		<textarea name="message" rows="3" cols="70" class="form-control" placeholder="Enter your motto"disabled><?php echo $row['motto']; ?> </textarea>
		<br>
		<br>
		</div>
		

		
		</div>	
	</div>	
  </form>
  </div>
    <div id="map" style="
	height: 400px;
    width: 296px;
    position: relative;
    overflow: hidden;
    right:-1029px;
    top: -2200px;
}
	"> </div>
  </div>
</div>

<div style="height: 400px;">

	 
</div>
  <script >
  function special(selected){
	 
	  console.log(selected);
	// var obj=that; //fetched from daycare
	// var selected = that.options[that.selectedIndex].value;
	 var  divSpecial= document.getElementById("specialA"); // div Type of Special Needs School
	 var textarea = document.getElementById("text_area"); //rest of the form
	 var divSpecialB = document.getElementById("specialB"); //div for Do you offer special needs classes
	 // var selectedA = document.getElementById("specialC").value; // div for Type of Special Needs Classe
	  
	 // var  divSpecialC= document.getElementById("specialB");
	 if(selected === 'special'){
		document.getElementById("specClass1").checked=false; //radio button yes uncheck
		document.getElementById("specClass2").checked =true ; //radio button no check
		//dayFeeID.value="";
		//document.getElementById("specOptsID").value=""; // clear special needs classes
		
		specialB.style.display= "none"; 	
		specialA.style.display = "block";
		console.log("special school");
		feeDivDayC.style.display = "none"; //div for fee range day care hidden
		feeDiv.style.display = "block";// dic for fee range shown
		
    }
	if(selected === 'daycare'){
		feeDiv.style.display = "none"; //div for fee range hidden
		feeDivDayC.style.display = "block"; //div for fee range day care show
		feeRangeID.value="";
		specialB.style.display= "block"; 	
		specialA.style.display = "none";
	}
    if(selected!=='special' && selected !=='daycare'){
		dayFeeID.value=""; //clear dayFee input
		feeDivDayC.style.display = "none"; //div for fee range day care hidden
		feeDiv.style.display = "block";// dic for fee range shown

		document.getElementById("errorspecialOptsA").style.display="none"; //remove error msg
		divSpecialB.style.display = "block";
        //textarea.style.display = "block";
		 divSpecial.style.display = "none";
		document.getElementById("specialOptsA").value=""; //clear set special needs schools 
		//document.getElementById("specialC").style.display="none"; 
		
    }
}
//if special needs is selected
function OnClickRadio(that){
	var radiobuttn=that.value;
	if(radiobuttn=='Yes'){
		document.getElementById("specialC").style.display="block"; // div for Type of Special Needs Classes:
		console.log('Hello');
	}
	else{
		document.getElementById("errorspecialOptsB").style.display="none"; 
		//document.getElementById("specOptsID").value="";
		document.getElementById("specialC").style.display="none"; 
	}
	console.log(radiobuttn);
}


  
  
  
  </script>  
  <script> 
 
//what happens when the page loads
window.onload = function() {	
console.log(selectSpecial.options[selectSpecial.selectedIndex].value);
if(selectSpecial.options[selectSpecial.selectedIndex].value==='special'){
	var specialID=selectSpecial.options[selectSpecial.selectedIndex].value;
	document.getElementById("jumbo").style.top="-910px"; 
	document.getElementById("map").style.top= "-2275px"; 
	console.log(specialID);
	special(specialID);
}

var z=document.getElementById("specClass1").checked; //radio button yes
var m = document.getElementById("specClass2").checked; //radio button no
		console.log(z);
		console.log(m);



	if (z){
	var k= document.getElementById("specClass1").value;	
	console.log(q);
	OnClickRadio(k);
		console.log('Yes');
}	
	if(m){
	var q =	document.getElementById("specClass2").value; 
	console.log(q);
	OnClickRadio(q);
	console.log('no');
	}
}



	

</script>


<script>
function myTracker(id){
console.log(id);
//'add_location1.php?name=' + name + '&address=' + address +
window.location.href='tracking.php?id=' + id;

}

</script>
<script>


		
      var customLabel = {
        kindergaten: {
          label: 'K'
        },
        primary: {
          label: 'P'
        },
		special:{
			label: 'S'
		},
		daycare:{
			label: 'D'
		}
      };

        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(-1.2920, 36.8219),
          zoom: 13
		  
        });
        var infoWindow = new google.maps.InfoWindow;
		var id = document.getElementById('SCH_ID').value;
          // Change this depending on the name of your PHP or XML file
          downloadUrl('http://localhost/school/ProfileMap.php?id='+id, function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
			 //var bounds = new google.maps.LatLngBounds();
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var name = markerElem.getAttribute('name');
              var address = markerElem.getAttribute('address');
              var type = markerElem.getAttribute('type');
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = name
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));
			
				map.setCenter(point);
			
			
              var text = document.createElement('text');
              text.textContent = address
              infowincontent.appendChild(text);
              var icon = customLabel[type] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label
              });
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
  




</script>
<script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDj8AVejS_y_93KkYOc0Tsq86SRNk5l7lM&callback=initMap">
    </script>

</body>


