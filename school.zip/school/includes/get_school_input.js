function special(that){
	 var obj=that; //fetched from daycare
	 var selected = obj.options[obj.selectedIndex].value;
	 var  divSpecial= document.getElementById("specialA"); // div Type of Special Needs School
	 var textarea = document.getElementById("text_area"); //rest of the form
	 var divSpecialB = document.getElementById("specialB"); //div for Do you offer special needs classes
	 // var selectedA = document.getElementById("specialC").value; // div for Type of Special Needs Classe
	  
	 // var  divSpecialC= document.getElementById("specialB");
	 if(selected === 'special'){
		document.getElementById("specClass1").checked=false; //radio button yes uncheck
		document.getElementById("specClass2").checked =true ; //radio button no check
		dayFeeID.value="";
		document.getElementById("specOptsID").value=""; // clear special needs classes
		
		specialB.style.display= "none"; 	
		specialA.style.display = "block";
		console.log("special school");
		feeDivDayC.style.display = "none"; //div for fee range day care hidden
		feeDiv.style.display = "block";// dic for fee range shown
		
    }
	if(selected === 'daycare'){
		feeDiv.style.display = "none"; //div for fee range hidden
		feeDivDayC.style.display = "block"; //div for fee range day care show
		feeRangeID.value="";
		specialB.style.display= "block"; 	
		specialA.style.display = "none";
	}
    if(selected!=='special' && selected !=='daycare'){
		dayFeeID.value=""; //clear dayFee input
		feeDivDayC.style.display = "none"; //div for fee range day care hidden
		feeDiv.style.display = "block";// dic for fee range shown

		document.getElementById("errorspecialOptsA").style.display="none"; //remove error msg
		divSpecialB.style.display = "block";
        //textarea.style.display = "block";
		 divSpecial.style.display = "none";
		document.getElementById("specialOptsA").value=""; //clear set special needs schools 
		//document.getElementById("specialC").style.display="none"; 
		
    }
}
//if special needs is selected
function OnClickRadio(that){
	var radiobuttn=that.value;
	if(radiobuttn=='Yes'){
		document.getElementById("specialC").style.display="block"; // div for Type of Special Needs Classes:
		console.log('Hello');
	}
	else{
		document.getElementById("errorspecialOptsB").style.display="none"; 
		document.getElementById("specOptsID").value="";
		document.getElementById("specialC").style.display="none"; 
	}
	console.log(radiobuttn);
}

