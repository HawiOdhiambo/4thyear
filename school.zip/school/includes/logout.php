<?php
if(!empty($_POST["logout"])) {
	$_SESSION["User_ID"] = "";
	session_destroy();
	header("location:login.php");
	}
?>