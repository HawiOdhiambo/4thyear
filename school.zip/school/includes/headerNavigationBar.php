<?php

	require ("db.php");
	session_start();
	$id = $_SESSION['User_ID'];
	$result = mysqli_query($conn,"SELECT * FROM users WHERE User_ID = $id ");
	$row  = mysqli_fetch_array($result);
if(!empty($_POST["logout"])) {
	$_SESSION["User_ID"] = "";
	session_destroy();
	header("location:login.php");
	}
	
?>


<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse" style="position: fixed; top: 0px; width: 100%; z-index:100;">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="http://localhost/school/school_homepage.php">Home</a></li>
      
      </ul>
	  
      <ul class="nav navbar-nav navbar-right">
		<li class="navbar-text">Welcome <?php echo ucwords($row['School_name']); ?>!</li>
        <li><form action="" method="post" id="frmLogout"> <input type="submit" name="logout" value="Logout" class="btn btn-danger">	</form></li>
      </ul>
    </div>
  </div>
</nav>



